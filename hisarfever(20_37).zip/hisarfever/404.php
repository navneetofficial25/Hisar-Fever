<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package HisarFever
 */

get_header();
require_once get_template_directory() . '/template-parts/model.php';
?>
	<div id="banner">
    <div class="hdr">
        <div class="container">
                <div class="banner-text text-center">
                    <div class="contect">
                        <h1>Ready To <b>Grow Your Business</b></h1>
                        <p>Contact us to work with a result driven digital marketing agency</p>
                        <div class="row">
                            <div class="col-md-5">
                                <a class="btn" data-toggle="modal" data-target="#modalLoginForm"><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-2.png">Get Free Proposal</a>
                            </div>
                            <div class="col-md-2">
                                <div class="or">
                                    <p>or</p>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <a class="btn" href=""><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-1.png">Call 925 400 0000</a>
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<section class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title"><?php esc_html_e( 'Oops! That page can&rsquo;t be found.', 'hisar-fever' ); ?></h1>
				</header><!-- .page-header -->

				<div class="page-content page-404">
					<h1 class="oops-404"><?php esc_html_e( 'Oops!!! 404 Page Not Found', 'hisar-fever' ); ?></h1>
						<p class="oops-404"><?php esc_html_e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'hisar-fever' ); ?></p></div>

					<?php
					get_search_form();

					//the_widget( 'WP_Widget_Recent_Posts' );
					?>


				</div><!-- .page-content -->
			</section><!-- .error-404 -->

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
