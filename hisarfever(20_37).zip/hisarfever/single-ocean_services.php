<?php

/**

 * The template for displaying all single EVENTS posts

 *

 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post

 *

 * @package education

 */



get_header();

if (function_exists('the_breadcrumb')) the_breadcrumb(); 
?>

<style>

    

    .blog-view p,li{

        font-size : 15px;

    }

    .blog-view span{

        line-height: 37px;

    }

    .blog-view a{

        color : black;

    }

    .blog-view a:hover{

        color : #ffd101;

    }

    .thumbnail img {
    	text-align: center;
    }

    .blog-view .card-header img{

        height : 100px;

    }

    .comment-author img{border-radius: 50%; width:65px;height:60px;}

    .user_name{

        font-size:14px;

        font-weight: bold;

    }

    .comments-list .media{

        border-bottom: 1px dotted #ccc;

    }

    .popular-img{

        max-width : none;

        height : auto;

        width : 90px;

    }

</style>



<main id="primary" class="site-main">



		<?php

		while ( have_posts() ) :

			the_post();

						//get_template_part( 'template-parts/content-page', get_post_type() ); ?>
							<section class="hisar-single-blog-warper">

						        <div class="single-blog">

						            <div class="container">

						                <div class="row">

							                <div class="col-md-12 col-sm-12 col-lg-12 blog-padding">

							                    <div class="right-blog">

							                        <div class="blog-cont">

							                            <div class="blog-view">

							                            	<div class="hisar-blog-tittle">

							                            	<h1><?php the_title(); ?></h1>

							                            </div>

			                            				<?php the_content(); ?>

		                        					</div>
		                        				</div>
		                        				<?php the_post_navigation(

				array(

					'prev_text' => '<span class="nav-subtitle">' . esc_html__( 'Previous:', 'hisarfever' ) . '</span> <span class="nav-title">%title</span>',

					'next_text' => '<span class="nav-subtitle">' . esc_html__( 'Next:', 'hisarfever' ) . '</span> <span class="nav-title">%title</span>',

				)

			);
			?>
		                        			</div>
		                        		</div>
		                        	</div>
		                        </div>
		                    </div>
		                </section>
		                        				<?php 

			// get_template_part( 'template-parts/content', get_post_type() );



			



			// If comments are open or we have at least one comment, load up the comment template.

			/*if ( comments_open() || get_comments_number() ) :

				comments_template();

			endif;*/



		endwhile; // End of the loop.

		?>



	</main><!-- #main -->



<?php

// get_sidebar();

get_footer();