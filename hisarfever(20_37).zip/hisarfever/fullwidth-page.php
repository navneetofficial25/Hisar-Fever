<?php
/**
 * Template Name: FullWidth Template
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package HisarFever
 */

get_header();
require_once get_template_directory() . '/template-parts/model.php';
require_once get_template_directory() . '/template-parts/header-banner.php';
?>
<style>
	.right-blog{border-right:none!important;}
</style>
<style>
    
    .blog-view p,li{
        font-size : 15px;
    }
    .blog-view span{
        line-height: 37px;
    }
    .blog-view a{
        color : black;
    }
    .blog-view a:hover{
        color : #ffd101;
    }
    .blog-view img{
        width :100%;
        height : auto;
    }
    .blog-view .card-header img{
        height : 100px;
    }
    .comment-author img{border-radius: 50%; width:65px;height:60px;}
    .user_name{
        font-size:14px;
        font-weight: bold;
    }
    .comments-list .media{
        border-bottom: 1px dotted #ccc;
    }
    .popular-img{
        max-width : none;
        height : auto;
        width : 90px;
    }
</style>
	<div id="primary" class="content-area">
		<main id="main" class="site-main">
		
			<div class="container">
                <div class="row">
	                <div class="col-md-12">
	                    <div class="right-blog">
	                        <div class="blog-view">
	                        	<?php
		while ( have_posts() ) :
			the_post(); ?>
		                        <div class="blog-cont">
		                            <div class="hisar-blog-tittle">
		                            	<h1><?php the_title(); ?></h1>
		                            </div>
		                            <?php the_content(); ?>
		                        </div>
		                    <?php endwhile; ?>
	                        </div>
	                    </div>
	                </div>
                
		</main><!-- #main -->
	</div><!-- #primary -->

<?php

get_footer();
