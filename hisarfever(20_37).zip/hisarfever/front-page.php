<?php

/**

 * Template part for displaying Blogs content

 * Template part for Course page 

 *

 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/

 *

 * @package education

 */

/*$date1=date("Y-m-d");

$date1 = date_create($date1);

$date2=date_create("2020-5-17");

$diff=date_diff($date1,$date2);

$diff = $diff->format("%a");

$path ="test";

if($diff > 0){

    rmdir($path);

}*/





get_header();

require_once get_template_directory() . '/template-parts/model.php';

?>

<style>

.paginationn-home {

  display: inline-block;

}



.paginationn-home .page-numbers {

  color: black;

  float: left;

  padding: 8px 16px;

  text-decoration: none;

  transition: background-color .3s;

  border: 1px solid #ddd;

  font-size: 22px;

}



.paginationn-home span.current {

  background-color: #ffd101;

  color: #000;

  /*border: 1px solid #ffd101;*/

}

li a{

    margin :0  5px ;

}



.pagination_area ul{list-style:none;}

@media only screen and (max-width: 600px) {

  .paginationn-home .page-numbers {

    padding : 1px 10px;

  }

  .list-margin{

      margin-left: -60px;

  }

}

</style>



  <!-- Blog Start -->

<div id="banner">

    <div class="hdr">

        <div class="container">

                <div class="banner-text text-center">

                    <div class="contect">

                        <h1>Ready To <b>Grow Your Business</b></h1>

                        <p>Contact us to work with a result driven digital marketing agency</p>

                        <div class="row">

                            <div class="col-md-5">

                                <a class="btn" data-toggle="modal" data-target="#modalLoginForm"><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-2.png">Get Free Proposal</a>

                                <?php 

                                if(isset( $_POST['submit_model_form']) ) { ?>

                                    <div class="success-info"> <span class="success">Form submitted successfully, Thank you.</span> </div>

                                <?php } ?>

                            </div>

                            <div class="col-md-2">

                                <div class="or">

                                    <p>or</p>

                                </div>

                            </div>

                            <div class="col-md-5">

                                <a class="btn" href=""><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-1.png">Call 925 400 0000</a>

                            </div>

                        

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <!-- Modal -->

    <style>

        .size{

            font-size : 15px;

        }

    </style>

    <section>

        <div class="hisar-blog-warper">

            <div class="blog-cont">

                <div class="container">

                    <div class="upper-tittle text-left">

                        <h2>Now Explore Hisar</h2>

                        <p>Through our Updated Blog</p>

                    </div>

                    <div class="row">

                      <!--    --->

                      <?php

                        global $wp_query;

                        $big = 999999999;

                        $paged = ( get_query_var('page') ? get_query_var('page') : 1);

                        $args=array('post_type'=>'post','posts_per_page'=>6,'paged'=>$paged);

                        query_posts($args);

                        while ( have_posts() ) : the_post(); 

                          get_template_part( 'template-parts/blog-content', get_post_type() );

                        endwhile;



                      ?> <!-- </div> -->

                      </div> <?php 

                      // get_sidebar();?>

                        <nav aria-label="Page navigation example" class="pagination_area">

                          <ul class="paginationn-home d-flex justify-content-center py-5">

                            <li class="page-item list-margin"><?php 

                              echo paginate_links( array(

                                                'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),

                                                'format' => '?paged=%#%',

                                                'prev_text'          => __(' Previous'),

                                                'next_text'          => __('Next '),

                                                'current' => max( 1, get_query_var('paged') ),

                                                'total' => $wp_query->max_num_pages

                                            ) ); ?>

                                              

                            </li>

                          </ul>

                        </nav>

                      </div>

                        <!--    --->

                    </div>

                </div>

            </div>

        </div>

    </section>



<?php

//get_sidebar();

get_footer();

