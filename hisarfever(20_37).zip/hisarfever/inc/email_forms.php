<?php 

$errors = new WP_Error();
$audit_error = array();
$contact_error = array();

if(isset($_POST['send_audit_mail'])) {

	if (empty($_POST['person_name'])) {
        $errors->add('empty_name', __('Please enter your name.', 'property-form'));
    }
    if (empty($_POST['email'])) {
        $errors->add('empty_email', __('Please enter your email.', 'property-form'));
    }
    if (empty($_POST['contact'])) {
        $errors->add('empty_contact', __('Please enter your contact.', 'property-form'));
    }

    if(count($errors->errors)>0) {
		$audit_error = $errors->errors;
	} else{
		//echo 'kriiii'; exit;
	  	$p_name		= $_POST['person_name'];
	  	$email 		= $_POST['email'];
	  	$contact	= $_POST['contact'];
	  	$company	= isset($_POST['company']) ? $_POST['company'] : '';
	  	$message 	= isset($_POST['message']) ? $_POST['message'] : '';
	  	$content = '<p>Contact Name - '.$p_name.'</p><p>Contact Email - '.$email.'</p><p>Contact Number - '.$contact.'</p><p>company Name - '.$company.'</p><p>Message - '.$message.'</p> ';

	  	$to = 'hisarfever@gmail.com';
		$subject = 'Mail From Business Audit';
		$email_body = $content;
		$headers = array('Content-Type: text/html; charset=UTF-8');
	 
		$audit_mail_info = wp_mail( $to, $subject, $email_body, $headers );
	}

}

/* Contact Form */

if(isset($_POST['contact_mail'])) {

	if (empty($_POST['person_name'])) {
        $errors->add('empty_name', __('Please enter your name.', 'property-form'));
    }
    if (empty($_POST['email'])) {
        $errors->add('empty_email', __('Please enter your email.', 'property-form'));
    }
    if (empty($_POST['phone'])) {
        $errors->add('empty_phone', __('Please enter your contact.', 'property-form'));
    }

    if(count($errors->errors)>0) {
		$contact_error = $errors->errors;
	} else {
		//echo 'kriiii'; exit;
	  	$p_name		= $_POST['person_name'];
	  	$email 		= $_POST['email'];
	  	$contact	= $_POST['phone'];
	  	$company	= isset($_POST['company']) ? $_POST['company'] : '';
	  	$web_url	= isset($_POST['web_url']) ? $_POST['web_url'] : '';
	  	$message 	= isset($_POST['message']) ? $_POST['message'] : '';
	  	$content = '<p>Contact Name - '.$p_name.'</p><p>Contact Email - '.$email.'</p><p>Contact Number - '.$contact.'</p><p>company Name - '.$company.'</p><p>company Url - '.$web_url.'</p><p>Message - '.$message.'</p> ';

	  	$to = 'hisarfever@gmail.com';
		$subject = 'Mail From Contact Form';
		$email_body = $content;
		$headers = array('Content-Type: text/html; charset=UTF-8');
	 
		$form_mail_info = wp_mail( $to, $subject, $email_body, $headers );
	}

}

/** Hisar Fever Proposal **/

if(isset($_POST['submit_model_form'])) {
	//echo 'yes'; exit;
  	$fullname		= $_POST['fullname'];
  	$email 			= $_POST['email'];
  	$contact		= $_POST['contact'];
  	$city			= $_POST['city'];

  	$content = '<p>Contact Name - '.$fullname.'</p><p>Contact Email - '.$email.'</p><p>Contact Number - '.$contact.'</p><p>City - '.$city.'</p> ';

  	$to = 'hisarfever@gmail.com';
	$subject = 'Mail From Proposal Form'; 
	$email_body = $content;
	$headers = array('Content-Type: text/html; charset=UTF-8');
 
	$form_mail_info = wp_mail( $to, $subject, $email_body, $headers );
}