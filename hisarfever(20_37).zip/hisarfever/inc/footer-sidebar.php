
<?php

function hisar_fever_widgets_footer1() {
	register_sidebar( array(
		'name'          => esc_html__( 'Footer 1', 'hisar-fever' ),
		'id'            => 'footer-1',
		'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),
		'before_widget' => '<section id="%1$s" class="hisar-widget-custom widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'hisar_fever_widgets_footer1' );



function hisar_fever_widgets_footer2() {
	register_sidebar( array(
		'name'          => esc_html__( 'Footer 2', 'hisar-fever' ),
		'id'            => 'footer-2',
		'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),
		'before_widget' => '<section id="%1$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'hisar_fever_widgets_footer2' );


function hisar_fever_widgets_footer3() {
	register_sidebar( array(
		'name'          => esc_html__( 'Footer 3', 'hisar-fever' ),
		'id'            => 'footer-3',
		'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),
		'before_widget' => '<section id="%1$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'hisar_fever_widgets_footer3' );


function hisar_fever_widgets_footer4() {
	register_sidebar( array(
		'name'          => esc_html__( 'Footer 4', 'hisar-fever' ),
		'id'            => 'footer-4',
		'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),
		'before_widget' => '<section id="%1$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
}
add_action( 'widgets_init', 'hisar_fever_widgets_footer4' );