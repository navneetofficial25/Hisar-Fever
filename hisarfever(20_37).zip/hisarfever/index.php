<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package education
 */

get_header();

require_once get_template_directory() . '/template-parts/model.php';
require_once get_template_directory() . '/template-parts/header-banner.php';
?>
<style>

.paginationn-home {

  display: inline-block;

}



.paginationn-home .page-numbers {

  color: black;

  float: left;

  padding: 8px 16px;

  text-decoration: none;

  transition: background-color .3s;

  border: 1px solid #ddd;

  font-size: 22px;

}



.paginationn-home span.current {

  background-color: #ffd101;

  color: #000;

  /*border: 1px solid #ffd101;*/

}

li a{

    margin :0  5px ;

}



.pagination_area ul{list-style:none;}

@media only screen and (max-width: 600px) {

  .paginationn-home .page-numbers {

    padding : 1px 10px;

  }

  .list-margin{

      margin-left: -60px;

  }

}

</style>
  
     <div id="fh5co-blog fh5-course">
        <div class="container">
           <div class="row">            
                    <!-- <div class="col-lg-10"> -->
    <?php
    if ( have_posts() ) :

      /*if ( is_home() && ! is_front_page() ) :
        ?>
        <header>
          <h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
        </header>
        <?php
      endif;*/

      /* Start the Loop */
      while ( have_posts() ) :
        the_post();

        /*
         * Include the Post-Type-specific template for the content.
         * If you want to override this in a child theme, then include a file
         * called content-___.php (where ___ is the Post Type name) and that will be used instead.
         */
        get_template_part( 'template-parts/blog-content', get_post_type() );

      endwhile;

      // the_posts_navigation();

    else :

      get_template_part( 'template-parts/content', 'none' );

    endif;
    ?> <!-- </div> -->
    </div> <?php 
    // get_sidebar();?>
      <nav aria-label="Page navigation example" class="pagination_area">
                <ul class="paginationn-home d-flex justify-content-center py-5">
                    <li class="page-item list-margin"><?php 
                    echo paginate_links();?></li>
                </ul>
            </nav>
    </div>
    </div><!-- #primary -->

<?php
// get_sidebar();
get_footer();
