

( function ( $ ) {
'use strict';

jQuery(function() {
  jQuery( ".success-info" ).delay( 3000 ).fadeOut( 1200 );
});


function verify() {

    console.log("[form verify ]");

	$("#NAME_ERROR_ID").hide();
	var name = $("#NAME_ID").val();
	console.log("firstName is ", name);
	if (isEmptyString (name)) {
		$("#NAME_ERROR_ID").show();
		$("#NAME_ID").focus();
		return false;
	}

	return true;
}

} (jQuery));
