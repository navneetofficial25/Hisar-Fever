<?php
/**
 * Template part for displaying Category content
 * Template part for Category page 
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package education
 */

get_header();

require_once get_template_directory() . '/template-parts/model.php';
?>
<style>
.paginationn-home {
  display: inline-block;
}

.paginationn-home .page-numbers {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
  font-size: 22px;
}

.paginationn-home span.current {
  background-color: #ffd101;
  color: #000;
  /*border: 1px solid #ffd101;*/
}
li a{
    margin :0  5px ;
}

.pagination_area ul{list-style:none;}
@media only screen and (max-width: 600px) {
  .paginationn-home .page-numbers {
    padding : 1px 10px;
  }
  .list-margin{
      margin-left: -60px;
  }
}
</style>

  <!-- Blog Start -->
<div id="banner">
    <div class="hdr">
        <div class="container">
                <div class="banner-text text-center">
                    <div class="contect">
                        <h1>Ready To <b>Grow Your Business</b></h1>
                        <p>Contact us to work with a result driven digital marketing agency</p>
                        <div class="row">
                            <div class="col-md-5">
                                <a class="btn" data-toggle="modal" data-target="#modalLoginForm"><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-2.png">Get Free Proposal</a>
                                <?php 
                                if(isset( $_POST['submit_model_form']) ) { ?>
                                    <div class="success-info"> <span class="success">Form submitted successfully, Thank you.</span> </div>
                                <?php } ?>
                            </div>
                            <div class="col-md-2">
                                <div class="or">
                                    <p>or</p>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <a class="btn" href=""><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-1.png">Call 925 400 0000</a>
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="hisar-single-blog-warper">
        <div class="single-blog">
            <div class="container">
                <div class="row">
                <div class="col-md-12 col-sm-12 col-lg-8 blog-padding">
                    <div class="right-blog">
                        <div class="blog-cont category-hisar-page">
                          <?php if ( have_posts() ) : ?>

                            <div class="blog-view">
                              <div class="hisar-blog-tittle">
                                  <!-- <h1>Category: <?php //single_cat_title( '', false ); ?></h1> -->
                              </div>
                              <?php while ( have_posts() ) : the_post(); ?>
                                <div class="card-cont">
                                  <div class="blog-img">
                                      <a href="<?php the_permalink(); ?>"  >
                                         <?php 
                                          if( has_post_thumbnail() ) {
                                              the_post_thumbnail('post-thumbnail-size');
                                          } else{
                                              ?><img src="<?php echo bloginfo('template_url');?>/assets/images/dummy.jpg"><?php 
                                          }
                                          

                                         ?>
                                      </a>
                                  </div>
                                  <div class="card-body">
                                      <h4><?php echo get_the_title(); ?></h4>
                                      <p><?php the_excerpt();?></p>
                                      <a class="btn-link" href="<?php echo esc_url( get_the_permalink($post) ) ?>">Read More...</a>
                                  </div>
                                  <div class="card-footer">
                                      <div class="card-user">
                                          <?php //echo wphf_get_post_views(get_the_ID()); 
                                              $author_id=$post->post_author;
                                          ?>
                                          <p>BY <?php echo ucfirst(get_the_author_meta('display_name', $author_id)); ?>  |  <?php the_date('F, jS '); ?></p>
                                      </div>
                                  </div>
                              </div>
                              <?php endwhile; 
 
                            else: ?>
                            <p>Sorry, no posts matched your criteria.</p>
                            <?php endif; ?>

                            </div>


                          </div>
                        </div>
                      </div>
                      <?php get_sidebar();
                      ?>
                    </div>
                  </div>
                </div>
    </section>

    <?php get_footer();