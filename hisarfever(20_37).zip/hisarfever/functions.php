<?php

/**

 * Hisar Fever functions and definitions

 *

 * @link https://developer.wordpress.org/themes/basics/theme-functions/

 *

 * @package Hisar_Fever

 */



if ( ! defined( '_S_VERSION' ) ) {

	// Replace the version number of the theme on each release.

	define( '_S_VERSION', '1.0.0' );

}



if ( ! function_exists( 'hisarfever_setup' ) ) :

	/**

	 * Sets up theme defaults and registers support for various WordPress features.

	 *

	 * Note that this function is hooked into the after_setup_theme hook, which

	 * runs before the init hook. The init hook is too late for some features, such

	 * as indicating support for post thumbnails.

	 */

	function hisarfever_setup() {

		/*

		 * Make theme available for translation.

		 * Translations can be filed in the /languages/ directory.

		 * If you're building a theme based on Hisar Fever, use a find and replace

		 * to change 'hisarfever' to the name of your theme in all the template files.

		 */

		load_theme_textdomain( 'hisarfever', get_template_directory() . '/languages' );



		// Add default posts and comments RSS feed links to head.

		add_theme_support( 'automatic-feed-links' );



		/*

		 * Let WordPress manage the document title.

		 * By adding theme support, we declare that this theme does not use a

		 * hard-coded <title> tag in the document head, and expect WordPress to

		 * provide it for us.

		 */

		add_theme_support( 'title-tag' );



		/*

		 * Enable support for Post Thumbnails on posts and pages.

		 *

		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/

		 */

		add_theme_support( 'post-thumbnails' );



		// This theme uses wp_nav_menu() in one location.

		register_nav_menus(

			array(

				'menu-1' => esc_html__( 'Primary', 'hisarfever' ),

			)

		);



		/*

		 * Switch default core markup for search form, comment form, and comments

		 * to output valid HTML5.

		 */

		add_theme_support(

			'html5',

			array(

				'search-form',

				'comment-form',

				'comment-list',

				'gallery',

				'caption',

				'style',

				'script',

			)

		);



		// Set up the WordPress core custom background feature.

		add_theme_support(

			'custom-background',

			apply_filters(

				'hisarfever_custom_background_args',

				array(

					'default-color' => 'ffffff',

					'default-image' => '',

				)

			)

		);



		// Add theme support for selective refresh for widgets.

		add_theme_support( 'customize-selective-refresh-widgets' );



		/**

		 * Add support for core custom logo.

		 *

		 * @link https://codex.wordpress.org/Theme_Logo

		 */

		add_theme_support(

			'custom-logo',

			array(

				'height'      => 250,

				'width'       => 250,

				'flex-width'  => false,

				'flex-height' => false,

			)

		);

	}

endif;

add_action( 'after_setup_theme', 'hisarfever_setup' );



/**

 * Set the content width in pixels, based on the theme's design and stylesheet.

 *

 * Priority 0 to make it available to lower priority callbacks.

 *

 * @global int $content_width

 */

function hisarfever_content_width() {

	// This variable is intended to be overruled from themes.

	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.

	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound

	$GLOBALS['content_width'] = apply_filters( 'hisarfever_content_width', 640 );

}

add_action( 'after_setup_theme', 'hisarfever_content_width', 0 );



/**

 * Register widget area.

 *

 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar

 */

function hisarfever_widgets_init() {

	register_sidebar( array(

    'name'          => esc_html__( 'Sidebar Hisar', 'hisar-fever' ),

    'id'            => 'sidebar-hisar',

    'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),

    'before_widget' => '<section id="%1$s" class="hisar-widget-custom widget %2$s">',

    'after_widget'  => '</section>',

    'before_title'  => '<h2 class="widget-title-hisar">',

    'after_title'   => '</h2>',

  ) );

}

add_action( 'widgets_init', 'hisarfever_widgets_init' );



/**

 * Enqueue scripts and styles.

 */

function hisarfever_scripts() {

	wp_enqueue_style( 'hisarfever-style', get_stylesheet_uri(), array(), _S_VERSION );

	wp_style_add_data( 'hisarfever-style', 'rtl', 'replace' );



	wp_enqueue_script( 'hisarfever-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );



	wp_enqueue_script( 'hisarfever-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), _S_VERSION, true );



	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {

		wp_enqueue_script( 'comment-reply' );

	}



	 /* Hisar Fever CSS */



    wp_enqueue_style( 'hisar-bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', false);

     /*Animate.css*/

    wp_enqueue_style( 'hisar-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css', false);



        wp_enqueue_style( 'hisar-custom', get_template_directory_uri() . '/assets/css/custom.css?v='.wp_rand( 10, 1000 ), false);

        wp_enqueue_style( 'hisar-fontawsome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', false);

        // wp_enqueue_style( 'hisar-custom', get_template_directory_uri() . '/assets/css/customm.css?v='.wp_rand( 10, 1000 ), false);





  #.....JS FILES....



    wp_enqueue_script( 'jquery.min', get_template_directory_uri() . '/assets/js/jquery.min.js' , array(), '', true );



    wp_enqueue_script( 'bootstrap.min', get_template_directory_uri() . '/assets/js/bootstrap.min.js' , array(), '', true );



    wp_enqueue_script( 'popper.min', get_template_directory_uri() . '/assets/js/popper.min.js' , array(), '', true );



        //wp_enqueue_script( 'custom', get_template_directory_uri() . '/assets/js/custom.js' , array(), '1.0.0', true );

}

add_action( 'wp_enqueue_scripts', 'hisarfever_scripts' );



/**

 * Implement the Custom Header feature.

 */

require get_template_directory() . '/inc/custom-header.php';



/**

 * Custom template tags for this theme.

 */

require get_template_directory() . '/inc/template-tags.php';



/**

 * Functions which enhance the theme by hooking into WordPress.

 */

require get_template_directory() . '/inc/template-functions.php';



/**

 * Customizer additions.

 */

require get_template_directory() . '/inc/customizer.php';



/**

 * Load Jetpack compatibility file.

 */

if ( defined( 'JETPACK__VERSION' ) ) {

	require get_template_directory() . '/inc/jetpack.php';

}







// Register Custom Navigation Walker

require_once get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php';





function hisar_fever_widgets_footer1() {

  register_sidebar( array(

    'name'          => esc_html__( 'Footer 1', 'hisar-fever' ),

    'id'            => 'footer-1',

    'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),

    'before_widget' => '<section id="%1$s" class="hisar-widget-custom widget %2$s">',

    'after_widget'  => '</section>',

    'before_title'  => '<h3>',

    'after_title'   => '</h3>',

  ) );

}

add_action( 'widgets_init', 'hisar_fever_widgets_footer1' );







function hisar_fever_widgets_footer2() {

  register_sidebar( array(

    'name'          => esc_html__( 'Footer 2', 'hisar-fever' ),

    'id'            => 'footer-2',

    'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),

    'before_widget' => '<section id="%1$s">',

    'after_widget'  => '</section>',

    'before_title'  => '<h3>',

    'after_title'   => '</h3>',

  ) );

}

add_action( 'widgets_init', 'hisar_fever_widgets_footer2' );





function hisar_fever_widgets_footer3() {

  register_sidebar( array(

    'name'          => esc_html__( 'Footer 3', 'hisar-fever' ),

    'id'            => 'footer-3',

    'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),

    'before_widget' => '<section id="%1$s">',

    'after_widget'  => '</section>',

    'before_title'  => '<h3>',

    'after_title'   => '</h3>',

  ) );

}

add_action( 'widgets_init', 'hisar_fever_widgets_footer3' );





function hisar_fever_widgets_footer4() {

  register_sidebar( array(

    'name'          => esc_html__( 'Footer 4', 'hisar-fever' ),

    'id'            => 'footer-4',

    'description'   => esc_html__( 'Add widgets here.', 'hisar-fever' ),

    'before_widget' => '<section id="%1$s">',

    'after_widget'  => '</section>',

    'before_title'  => '<h3>',

    'after_title'   => '</h3>',

  ) );

}

add_action( 'widgets_init', 'hisar_fever_widgets_footer4' );





require_once get_template_directory() . '/template-parts/custom_breadcrumbs.php';









function hisarfever_custom_excerpt_length($length) {

  global $post;

  if ($post->post_type == 'ocean_services') {

    return 25;

  }



  if ($post->post_type == 'post') {

    return 35;

  }



  return $length;

}

add_filter('excerpt_length', 'hisarfever_custom_excerpt_length');







/* Custom callback function for Trackbacks/Pings, see comments.php */

function custom_pings($comment, $args, $depth) {

   $GLOBALS['comment'] = $comment; ?>

   <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">

     <div id="comment-<?php comment_ID(); ?>">

      <div class="media mb-4">

         

         <?php printf(__('<h5 class="mt-0">%s</h5> <span class="mt-0">wrote:</span>'), get_comment_author_link()) ?>

      </div>

      <?php if ($comment->comment_approved == '0') : ?>

         <em><?php _e('Your comment is awaiting moderation.') ?></em>

         <br />

      <?php endif; ?>



      <div class="comment-meta commentmetadata"><a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ) ?>"><?php printf(__('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></a><?php edit_comment_link(__('(Edit)'),'  ','') ?></div>



      <?php comment_text() ?>

      

     </div>

<?php

}









function mytheme_comment($comment, $args, $depth) { 

    if ( 'div' === $args['style'] ) {

        $tag       = 'div';

        $add_below = 'comment';

    } else {

        $tag       = 'li';

        $add_below = 'div-comment';

    }?>

    <<?php echo $tag; ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?> id="comment-<?php comment_ID() ?>"><?php 

    if ( 'div' != $args['style'] ) { ?>

        <div id="div-comment-<?php comment_ID() ?>" class="comment-body"><?php

    } ?>

    <div class="comments-list">

      <div class=" media">

          <div class="media-left">

            <?php 

              if ( $args['avatar_size'] != 0 ) {

                  echo get_avatar( $comment, $args['avatar_size'] ); 

              } 

              ?>

          </div><?php 

          if ( $comment->comment_approved == '0' ) { ?>

              <em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.' ); ?></em><br/><?php 

          } ?>

          <!-- <div class="comment-meta commentmetadata"> -->

          <div class="media-body"> 

          <!-- <div class=" comment-meta commentmetadata">  -->

            <?php printf( __( '<h4 class="media-heading user_name">%s</h4>' ), get_comment_author_link() ); ?>

              <a class="comment-user" href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>"><p class="comment-date"><?php

                  /* translators: 1: date, 2: time */

                  printf( 

                      __('%1$s at %2$s'), 

                      get_comment_date(),  

                      get_comment_time() 

                  ); ?>

              </p></a>

              <?php 

              edit_comment_link( __( '(Edit)' ), '  ', '' ); ?>

          <!-- </div> -->

          

          <div class="media-body">

            <?php comment_text(); ?> 

          <div class="reply"><?php 

                    comment_reply_link( 

                        array_merge( 

                            $args, 

                            array( 

                                'add_below' => $add_below, 

                                'depth'     => $depth, 

                                'max_depth' => $args['max_depth'] 

                            ) 

                        ) 

                    ); ?>

           </div>

        </div>

      </div>

    </div>

    </div>



      <?php 

    if ( 'div' != $args['style'] ) : ?>

        </div><?php 

    endif;

}







function placeholder_author_email_url_form_fields($fields) {

        $replace_author = __('Your Name', 'yourdomain');

        $replace_email = __('Your Email', 'yourdomain');

        $replace_url = __('Your Website', 'yourdomain');

        // $replace_comment = __('Comment', 'yourdomain');

         

         $req =''; $aria_req=''; $commenter = wp_get_current_commenter();

         $consent = isset($commenter['comment_author_email']) ? $commenter['comment_author_email'] : '';

            $fields['author'] ='<div class="row"><div class="col-md-4"><input class="input-info" id="input-info" name="author" type="text" placeholder="'.$replace_author.'" value="' . esc_attr( $commenter['comment_author'] ) . '" size="20"' . $aria_req . ' /></div>';

                        

            $fields['email'] = '<div class="col-md-4"><input class="input-info" id="input-info" name="email" type="text" placeholder="'.$replace_email.'" value="' . esc_attr(  $commenter['comment_author_email'] ) .

        '" size="30"' . $aria_req . ' /></div>';

        

            $fields['url'] = '<div class="col-md-4"><input name="url" class="input-info" id="input-info" type="text" placeholder="'.$replace_url.'" value="' . esc_attr( $commenter['comment_author_url'] ) .

        '" size="30" /></div>';



            $fields['cookies'] = '<p style="margin-left:20px; margin-top:10px;" class="comment-form-cookies-consent cookies-comt-form"><input id="wp-comment-cookies-consent" id="wp-comment-cookies-consent" name="wp-comment-cookies-consent" type="checkbox" value="yes"' . $consent . ' /><span style="margin-left:20px;" class="wp-comment-cookies-consent">' . __( 'Save my name, email, and website in this browser for the next time I comment', 'yourdomain' ) . '</span></p></div>';    



        return $fields;

}

add_filter('comment_form_default_fields','placeholder_author_email_url_form_fields');



/**

 * Comment Form Placeholder Comment Field

 */

function placeholder_comment_form_field($fields) {

        $replace_comment = __('Comment', 'yourdomain');



            $fields['comment_field'] = '<textarea id="comment" rows="3" name="comment" cols="45" rows="10"  placeholder="'.$replace_comment.'" aria-required="true"></textarea>';

         

        return $fields;

     }



add_filter( 'comment_form_defaults', 'placeholder_comment_form_field' );









add_action( 'add_meta_boxes', 'wphf_add_portfolio_video_metaboxes' );



function wphf_add_portfolio_video_metaboxes() {

  add_meta_box(

    'wphf_video_url',

    'Video Link Url',

    'wphf_video_url',

    'ocean_portfolio',

    'advanced',

    'default'

  );



  add_meta_box(

    'wphf_heading',

    'Banner Heading',

    'wphf_banner_heading',

    'post',

    'advanced',

    'default'

  );



  add_meta_box(

    'wphf_subheading',

    'Banner Sub Heading',

    'wphf_banner_subheading',

    'post',

    'advanced',

    'default'

  );

}



function wphf_video_url() {

  global $post;



  // Nonce field to validate form request came from current site

  wp_nonce_field( basename( __FILE__ ), 'video_url_field_nonce' );



  // Get the location data if it's already been entered

  $video_url = get_post_meta( $post->ID, 'video_url', true );



  // Output the field

  echo '<input type="text" name="video_url" value="' . esc_textarea( $video_url )  . '" class="widefat">';

  echo '<p class="howto">Please Insert video link url here</p>';



}



/**

 * Save the metabox data

 */

function wpt_save_portfolio_video_meta( $post_id, $post ) {



  // Return if the user doesn't have edit permissions.

  if ( ! current_user_can( 'edit_post', $post_id ) ) {

    return $post_id;

  }



  // Verify this came from the our screen and with proper authorization,

  // because save_post can be triggered at other times.

  if ( ! isset( $_POST['video_url'] ) || ! wp_verify_nonce( $_POST['video_url_field_nonce'], basename(__FILE__) ) ) {

    return $post_id;

  }



  // Now that we're authenticated, time to save the data.

  // This sanitizes the data from the field and saves it into an array $events_meta.

  $video_meta['video_url'] = esc_textarea( $_POST['video_url'] );



  // Cycle through the $events_meta array.

  // Note, in this example we just have one item, but this is helpful if you have multiple.

  foreach ( $video_meta as $key => $value ) :



    // Don't store custom data twice

    if ( 'revision' === $post->post_type ) {

      return;

    }



    if ( get_post_meta( $post_id, $key, false ) ) {

      // If the custom field already has a value, update it.

      update_post_meta( $post_id, $key, $value );

    } else {

      // If the custom field doesn't have a value, add it.

      add_post_meta( $post_id, $key, $value);

    }



    if ( ! $value ) {

      // Delete the meta key if there's no value

      delete_post_meta( $post_id, $key );

    }



  endforeach;



}

add_action( 'save_post', 'wpt_save_portfolio_video_meta', 1, 2 );



/**** Banner Heading ****/
function wphf_banner_heading() {
  global $post;
  $heading = get_post_meta( $post->ID, 'wphf_heading', true );

  echo '<input type="text" name="wphf_heading" value="' . esc_textarea( $heading )  . '" class="widefat">';
  echo '<p class="howto">Please Insert heading here</p>';

}

function wpt_save_heading_meta( $post_id, $post ) {

  if ( ! current_user_can( 'edit_post', $post_id ) ) {
    return $post_id;
  }

//echo 'post id is - '.$post_id; exit;
  if ( isset( $_POST['wphf_heading'] ) ) {

    $heading_meta =  sanitize_text_field( $_POST['wphf_heading'] );

    update_post_meta($post_id, 'wphf_heading', $heading_meta );
  }

}
add_action( 'save_post', 'wpt_save_heading_meta', 1, 2 );

/**** END Banner Heading ****/

/**** Banner SUb Heading ****/

function wphf_banner_subheading() {
  global $post;
  $subheading = get_post_meta( $post->ID, 'wphf_subheading', true );
  echo '<input type="text" name="wphf_subheading" value="' . esc_textarea( $subheading )  . '" class="widefat">';
  echo '<p class="howto">Please Insert sub heading here</p>';

}

function wpt_save_subheading_meta( $post_id, $post ) {

  if ( ! current_user_can( 'edit_post', $post_id ) ) {
    return $post_id;
  }

  if ( isset( $_POST['wphf_subheading'] ) ) {

    $heading_meta =  sanitize_text_field( $_POST['wphf_subheading'] );
    
    update_post_meta($post_id, 'wphf_subheading', $heading_meta );
  }

}
add_action( 'save_post', 'wpt_save_subheading_meta', 1, 2 );

/**** Banner Heading ****/





function wphf_faq_post_type() {

  $labels = array(

    'name'               => _x( 'FAQ', 'post type general name' ),

    'singular_name'      => _x( 'FAQ', 'post type singular name' ),

    'add_new'            => _x( 'Add New', 'FAQ' ),

    'add_new_item'       => __( 'Add New FAQ' ),

    'edit_item'          => __( 'Edit FAQ' ),

    'new_item'           => __( 'New FAQ' ),

    'all_items'          => __( 'All FAQ' ),

    'view_item'          => __( 'View FAQ' ),

    'search_items'       => __( 'Search FAQ' ),

    'not_found'          => __( 'No FAQ found' ),

    'not_found_in_trash' => __( 'No FAQ found in the Trash' ), 

    'parent_item_colon'  => '',

    'menu_name'          => 'FAQ'

  );

  $args = array(

    'labels'        => $labels,

    'description'   => 'Holds our FAQ\'s specific data',

    'public'        => true,

    'menu_position' => 5,

    'supports'      => array( 'title', 'editor'),

    'has_archive'   => true,

  );

  register_post_type( 'faq', $args ); 

}

add_action( 'init', 'wphf_faq_post_type' );





function wphf_portfolio_post_type() {

  $labels = array(

    'name'               => _x( 'Portfolio', 'post type general name' ),

    'singular_name'      => _x( 'Portfolio', 'post type singular name' ),

    'add_new'            => _x( 'Add New', 'Portfolio' ),

    'add_new_item'       => __( 'Add New Portfolio' ),

    'edit_item'          => __( 'Edit Portfolio' ),

    'new_item'           => __( 'New Portfolio' ),

    'all_items'          => __( 'All Portfolio' ),

    'view_item'          => __( 'View Portfolio' ),

    'search_items'       => __( 'Search Portfolio' ),

    'not_found'          => __( 'No Portfolio found' ),

    'not_found_in_trash' => __( 'No Portfolio found in the Trash' ), 

    'parent_item_colon'  => '',

    'menu_name'          => 'Portfolio'

  );

  $args = array(

    'labels'        => $labels,

    'description'   => 'Holds our Portfolio specific data',

    'public'        => true,

    'menu_position' => 5,

    'supports'      => array( 'title', 'thumbnail', 'excerpt' ),

    //'has_archive'   => true,

    //'taxonomies'    => array( 'portfolio-category' ),

  );

  register_post_type( 'ocean_portfolio', $args ); 

}

add_action( 'init', 'wphf_portfolio_post_type' );



// Register Custom Navigation Walker

require_once get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php';

//require_once get_template_directory() . '/inc/email_forms.php';



function portfolio_categories_taxonomy() {

 

// Add new taxonomy, make it hierarchical like categories

//first do the translations part for GUI

 

  $portfolio_cats = array(

    'name' => _x( 'Portfolio Categories', 'taxonomy general name' ),

    'singular_name' => _x( 'Portfolio Category', 'taxonomy singular name' ),

    'search_items' =>  __( 'Search Portfolio Categories' ),

    'all_items' => __( 'All Portfolio Categories' ),

    'parent_item' => __( 'Parent Portfolio Category' ),

    'parent_item_colon' => __( 'Parent Portfolio Category:' ),

    'edit_item' => __( 'Edit Portfolio Category' ), 

    'update_item' => __( 'Update Portfolio Category' ),

    'add_new_item' => __( 'Add New Portfolio Category' ),

    'new_item_name' => __( 'New Portfolio Category' ),

    'menu_name' => __( 'Portfolio Categories' ),

  );    

 

// Now register the taxonomy. Replace the parameter portfolios withing the array by the name of your custom post type.

  register_taxonomy('ocean_portfolio_category',array('ocean_portfolio'), array(

    'hierarchical' => true,

    'labels' => $portfolio_cats,

    'show_ui' => true,

    'show_admin_column' => true,

    'query_var' => true,

    'rewrite' => array( 'slug' => 'portfolio categories' ),

  ));

 

}

add_action( 'init', 'portfolio_categories_taxonomy', 0 );

//========================= Tags for Portfolio Custom Type ===========================//



//hook into the init action and call create_topics_nonhierarchical_taxonomy when it fires

function portfolio_tags_taxonomy() { 

// Labels part for the GUI

 

  $portfolio_tags = array(

    'name' => _x( 'Portfolio Tags', 'taxonomy general name' ),

    'singular_name' => _x( 'Portfolio Tag', 'taxonomy singular name' ),

    'search_items' =>  __( 'Search Portfolio Tags' ),

    'popular_items' => __( 'Popular Portfolio Tags' ),

    'all_items' => __( 'All Portfolio Tags' ),

    'parent_item' => null,

    'parent_item_colon' => null,

    'edit_item' => __( 'Edit Portfolio Tag' ), 

    'update_item' => __( 'Update Portfolio Tag' ),

    'add_new_item' => __( 'Add New Portfolio Tag' ),

    'new_item_name' => __( 'New Portfolio Tag Name' ),

    'separate_items_with_commas' => __( 'Separate portfolio tags with commas' ),

    'add_or_remove_items' => __( 'Add or remove portfolio tags' ),

    'choose_from_most_used' => __( 'Choose from the most used portfolio tags' ),

    'menu_name' => __( 'Portfolio Tags' ),

  );

 

// Now register the non-hierarchical taxonomy like tag. . Replace the parameter portfolios withing the array by the name of your custom post type.

  register_taxonomy('ocean_portfolio_tag','ocean_portfolio',array(

    'hierarchical' => false,

    'labels' => $portfolio_tags,

    'show_ui' => true,

    'show_admin_column' => true,

    'update_count_callback' => '_update_post_term_count',

    'query_var' => true,

    'rewrite' => array( 'slug' => 'portfolio tags' ),

  ));

}

add_action( 'init', 'portfolio_tags_taxonomy', 0 );







function wphf_service_post_type() {

  $labels = array(

    'name'               => _x( 'Services', 'post type general name' ),

    'singular_name'      => _x( 'Service', 'post type singular name' ),

    'add_new'            => _x( 'Add New', 'Service' ),

    'add_new_item'       => __( 'Add New Service' ),

    'edit_item'          => __( 'Edit Service' ),

    'new_item'           => __( 'New Service' ),

    'all_items'          => __( 'All Service' ),

    'view_item'          => __( 'View Service' ),

    'search_items'       => __( 'Search Service' ),

    'not_found'          => __( 'No Service found' ),

    'not_found_in_trash' => __( 'No Service found in the Trash' ), 

    'parent_item_colon'  => '',

    'menu_name'          => 'Service'

  );

  $args = array(

    'labels'        => $labels,

    'description'   => 'Holds our Services specific data',

    'public'        => true,

    'menu_position' => 5,

    'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),

    'has_archive'   => true,

    'rewrite' => array('slug' => 'seo'),

    'show_in_nav_menus' => true,

   // 'taxonomies'    => array( 'category' ),

  );

  register_post_type( 'ocean_services', $args ); 

}

add_action( 'init', 'wphf_service_post_type' );

remove_action('shutdown', 'wp_ob_end_flush_all', 1);



