<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package HisarFever
 */

/*if ( ! is_active_sidebar( 'sidebar-hisar' ) ) {
    return;
}*/
?>
<style>
    
    .blog-view p,li{
        font-size : 15px;
    }
    .blog-view span{
        line-height: 37px;
    }
    .blog-view a{
        color : black;
    }
    .blog-view a:hover{
        color : #ffd101;
    }
    .blog-view img{
        width :100%;
        height : auto;
    }
    .blog-view .card-header img{
        height : 100px;
    }
    .comment-author img{border-radius: 50%; width:65px;height:60px;}
    .user_name{
        font-size:14px;
        font-weight: bold;
    }
    .comments-list .media{
        border-bottom: 1px dotted #ccc;
    }
    .popular-img{
        max-width : none;
        height : auto;
        width : 90px;
    }

</style>
<div class="col-md-12 col-sm-12 col-lg-4">
    <div class="lft-blog">
        <div class="sidebar-box">
            

                <?php if ( is_active_sidebar( 'sidebar-hisar' ) ) {                      
                         dynamic_sidebar( 'sidebar-hisar' ); 
                      }
                ?>
            
        </div>
    </div>
</div>
<!-- #secondary -->
