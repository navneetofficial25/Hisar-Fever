<?php

/**

 * The template for displaying the footer

 *

 * Contains the closing of the #content div and all content after.

 *

 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials

 *

 * @package HisarFever

 */



?>



	</div><!-- #content -->

	 <div class="shadow-lg mt-4"  style="background-color: #fff;" id="footer">

        <div class="container ">

                <div class="row">

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 foot">

                        <div class="abt-info">

                           <?php if ( is_active_sidebar( 'footer-1' ) ) {                      

                                 dynamic_sidebar( 'footer-1' ); 

                              }

                            ?>

                        </div>

                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 foot" >

                        <div class="ser-info">

                            <?php if ( is_active_sidebar( 'footer-2' ) ) {                      

                                 dynamic_sidebar( 'footer-2' ); 

                              }

                            ?>

                        

                        </div>

                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 foot" >

                        <div class="qui-info">

                           

                            <?php if ( is_active_sidebar( 'footer-3' ) ) {                      

                                dynamic_sidebar( 'footer-3' ); 

                              }

                            ?>

                           

                        </div>

                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 foot" >

                        <div class="new-info">

                           

                            <?php if ( is_active_sidebar( 'footer-4' ) ) {                      

                                dynamic_sidebar( 'footer-4' ); 

                              }

                            ?>

                        </div>

                    </div>

                </div>

                <div class="footer-buttom">

                    <div class="">

                        <div class="copyrgt">

                            <div class="lft-copydd text-center">

                                <p>All Rights Reserved <?php echo date('Y'); ?> | <a target="_blank"href="<?php echo get_bloginfo('url'); ?>" target="blank"><?php echo get_bloginfo(); ?></a></p>

                            </div>

                        </div>

                    </div>

                </div>

        </div>

    </div>

	

</div><!-- #page -->

<script>
function myFunction(x) {
  if (x.matches) { // If media query matches

    element.classList.remove("mystyle2");
   element.classList.add("mystyle1");
   element1.classList.remove("mystyle4");
   element1.classList.add("mystyle3");
  } else {
    element.classList.remove("mystyle1");
   element.classList.add("mystyle2");
   element1.classList.remove("mystyle3");
   element1.classList.add("mystyle4");
  }

}
var element = document.getElementById("menu-item-21");
var element1 = document.getElementById("menu-item-3049");
var x = window.matchMedia("(max-width: 991px)")
myFunction(x) // Call listener function at run time
x.addListener(myFunction) // Attach listener function on state changes
</script>
<?php wp_footer(); ?>

</body>
</html>
