<?php
/**
 * WP Post Widget Hisar
 *
 * @package Maps
 * @author hisarfever
 * @copyright 2019 flippercode
 * 
 * @wordpress-plugin
 * Plugin Name: WP Post Widget Hisar
 * Plugin URI: http://www.hisarfever.com/
 * Description: post widget
 * Version: 1.0.0
 * Author: Hisarfever
 * Author URI: http://www.hisarfever.com/
 * Text Domain: hisar-fever
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

if ( ! class_exists( 'Post_Widget_Hisar' ) ) {

	class Post_Widget_Hisar {

		private $pluginUrl = '';
		private $pluginDir = '';

		public function __construct() {

			$this->pluginUrl = plugin_dir_url( __FILE__ );
			$this->pluginDir = trailingslashit(plugin_dir_path( __FILE__ ));

			//$this->load_files();
			$this->register_hooks();
			
		}

		function register_hooks() {

			add_action( 'widgets_init', array( $this, 'popular_post_widget' ) );
		}

		/*function load_files() {

			$dir = plugin_dir_path( __FILE__ );
			echo wp_slash($dir); exit;
			$coreInitialisationFile = $this->pluginDir . 'inc/class-popular-post-popular-widget.php';
			//if ( file_exists( $coreInitialisationFile ) ) {
				//echo 'hereee'; exit;
				require_once $coreInitialisationFile;
			//}
		}*/

		function popular_post_widget() {

			register_widget( 'Hisar_Fever_Popular_Post_Widget_Class' );
		}

	}

	new Post_Widget_Hisar();
}


if ( ! class_exists( 'Hisar_Fever_Popular_Post_Widget_Class' ) ) {

    class Hisar_Fever_Popular_Post_Widget_Class extends WP_Widget {
         
        function __construct() {

        	parent::__construct(
    				'Hisar_Fever_Popular_Post_Widget_Class',
    				'Popular Posts',
    				array( 'description' => esc_html__( 'A widget to display popular posts', 'wpgmp-google-map' ) )
    			);

        }
         
       public function widget( $args, $instance ) { ?>
                <?php

                    $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Recent Posts' );
                    $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
                    if ( ! $number ) {
                        $number = 5;
                    }

                    echo '<h4>'.$args['before_widget'].'<h4>';
                    if ( ! empty( $title ) )
                        echo '<h4>'.$args['before_title'] . $title . $args['after_title'].'<h4>';
                ?>

                <!-- <h4>Popular Posts</h4> -->
                <ul class="">
                    <?php 
                    $popularpost = new WP_Query(
                    apply_filters(
                    'widget_posts_args',
                        array(
                            'posts_per_page'      => $number,
                            'post_status'         => 'publish',
                            'meta_key' => 'wpb_post_views_count', 
                            'ignore_sticky_posts' => true,
                            'orderby' => 'meta_value_num', 
                            'order' => 'DESC'
                        ),
                        $instance
                        )
                    );

                    if ( ! $popularpost->have_posts() ) {
                        return;
                    }
                    ?>
                <ul>

                    <?php while ( $popularpost->have_posts() ) : $popularpost->the_post(); ?>
                    <li class="d-flex">
                        <a href="<?php the_permalink(); ?>" tittle="<?php the_title() ?>">
                            <?php 
                            if( has_post_thumbnail() ) {
                                echo the_post_thumbnail( 'thumbnail', array( 'class' => 'popular-img') );
                            } else{
                                ?><img width="50" height="50" src="<?php echo bloginfo('template_url');?>/assets/images/dummy.jpg"><?php 
                            }

                            ?>
                        </a>
                        <div class="recent-posts-details">
                            <div class="recent-posts-details-inner p-2">
                                <a href="<?php the_permalink(); ?>"><?php the_title() ?></a>
                                <div class="recent-posts-info">
                                    <p><?php the_date('F, jS '); ?> / <?php comments_number(); ?></p>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endwhile; wp_reset_query(); ?>
                </ul>
           
            <?php
           
            echo $args['after_widget'];
        }
                 
        // Widget Backend 
        public function form( $instance ) {

            if ( isset( $instance[ 'title' ] ) ) {
                $title = $instance[ 'title' ];
            }
            else {
                $title = __( 'New title', 'wpb_widget_domain' );
            }
            // Widget admin form
            ?>
            <p>
                <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
                <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_html( $this->get_field_id( 'title' ) ); ?>">
                    <?php esc_html_e( 'No of Posts:', 'wpgmp-google-map' ); 
                    $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 10;

                    ?>
                </label>
                <input type="number" class="widefat" style="margin-top:6px;" value="<?php echo $number; ?>" name="<?php echo esc_html( $this->get_field_name( 'number' ) ); ?>" >
            </p>
            <?php 
        }
             
        // Updating widget replacing old instances with new
        public function update( $new_instance, $old_instance ) {
            $instance['title']     = sanitize_text_field( $new_instance['title'] );
            $instance['number']    = (int) $new_instance['number'];

            return $instance;
        }
         
    } 
}
