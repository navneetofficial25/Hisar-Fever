<?php
/**
 * WP FAQs
 *
 * @package Maps
 * @author hisarfever
 * @copyright 2019 flippercode
 * 
 * @wordpress-plugin
 * Plugin Name: WP Hisar FAQs
 * Plugin URI: http://www.hisarfever.com/
 * Description: FAQs
 * Version: 1.0.0
 * Author: Hisarfever
 * Author URI: http://www.hisarfever.com/
 * Text Domain: hisar-fever
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

if ( ! class_exists( 'Post_FAQ_Hisar' ) ) {

	class Post_FAQ_Hisar {

		public function __construct() {

			$this->pluginUrl = plugin_dir_url( __FILE__ );
			$this->pluginDir = trailingslashit(plugin_dir_path( __FILE__ ));

			$this->register_hooks();
			
		}

		function register_hooks() {

			add_shortcode( 'hisar-faq', array($this, 'hisar_faq_shortcode') );
		}

        function hisar_faq_shortcode($contents) { ?>

            <?php ob_start(); ?>


                <style>
                    .accordion .card-header:after {
                    font-family: 'FontAwesome';  
                    content: "\f068";
                    float: right; 
                }
                .accordion .card-header.collapsed:after {
                    /* symbol for "collapsed" panels */
                    content: "\f067"; 
                }
            </style>


            <section>
                    <div class="hisar-questions-warper">
                        <div class="questions">
                            <div class="container">
                                <div class="question-tittle">
                                     <h1>FREQUENTLY ASKED</h1>
                                     <p>Common Questions</p>
                                </div>
                                <div id="accordion" class="accordion">
                                    <div class="card question-card mb-0">
                                    <?php $loop = new WP_Query( array( 'post_type' => 'faq', 'posts_per_page' => -1 ) ); ?>
                                    <?php while ( $loop->have_posts() ) : $loop->the_post(); ?> 
                                        <div class="card-header collapsed" id="question-card-header" data-toggle="collapse" href="#faq<?php echo get_the_ID(); ?>">
                                            <a class="card-title">
                                               <?php echo get_the_title(); ?>
                                            </a>
                                        </div>
                                    
                                        <div id="faq<?php echo get_the_ID(); ?>" class="panel-collapse collapse in">
                                            <div class="panel-body"><?php the_content(); ?></div>
                                        </div>

                                    <?php endwhile; wp_reset_query(); ?>

                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <?php
                $contents = '<div class="faq_listing">'.ob_get_contents().'</div>';
                ob_end_clean();
                
                return $contents;
            }


	}

	new Post_FAQ_Hisar();
}


