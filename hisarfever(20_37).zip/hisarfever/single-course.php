<?php
/**
 * The template for displaying all single EVENTS posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package education
 */

get_header();
?>

	 <div id="fh5co-course" class="fh5-course">
		<div class="container">
            <div class="row">
                <div class="col-lg-9">
					<?php
					while ( have_posts() ) :
						the_post();

						get_template_part( 'template-parts/single_cpt', get_post_type() );

						the_post_navigation();

						// If comments are open or we have at least one comment, load up the comment template.
						if ( comments_open() || get_comments_number() ) :
							comments_template();
						endif;

					endwhile; // End of the loop.
					?>
				 <!-- </div> -->
                </div>
                <div class="col-lg-3">
                <?php get_sidebar();?>
                </div>
            </div>                    
        </div>
        <nav aria-label="Page navigation example" class="pagination_area">
            <ul class="pagination">               
            </ul>
        </nav>
    </div>


<?php
// get_sidebar();
get_footer();
