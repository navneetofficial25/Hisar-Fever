<?php
/**
 * The template for displaying post single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package HisarFever
 */

get_header();
require_once get_template_directory() . '/template-parts/model.php';
// wphf_set_post_views(get_the_ID());
require_once get_template_directory() . '/template-parts/header-banner.php';
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();

			get_template_part( 'template-parts/blog-single', get_post_type() );

			//the_post_navigation();

			

		endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
//get_sidebar('custom');
get_footer();
