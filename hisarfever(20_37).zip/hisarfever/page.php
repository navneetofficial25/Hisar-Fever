<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Hisar_Fever
 */

get_header();
require_once get_template_directory() . '/template-parts/model.php';
require_once get_template_directory() . '/template-parts/header-banner.php';
?>
<style>
    
    .blog-view p,li{
        font-size : 15px;
    }
    .blog-view span{
        line-height: 37px;
    }
    .blog-view a{
        color : black;
    }
    .blog-view a:hover{
        color : #ffd101;
    }
    .blog-view img{
        width :100%;
        height : auto;
    }
    .blog-view .card-header img{
        height : 100px;
    }
    .comment-author img{border-radius: 50%; width:65px;height:60px;}
    .user_name{
        font-size:14px;
        font-weight: bold;
    }
    .comments-list .media{
        border-bottom: 1px dotted #ccc;
    }
    .popular-img{
        max-width : none;
        height : auto;
        width : 90px;
    }
</style>

<style>
.paginationn-home {
  display: inline-block;
}

.paginationn-home .page-numbers {
  color: black;
  float: left;
  padding: 8px 16px;
  text-decoration: none;
  transition: background-color .3s;
  border: 1px solid #ddd;
  font-size: 22px;
}

.paginationn-home span.current {
  background-color: #ffd101;
  color: #000;
  /*border: 1px solid #ffd101;*/
}
li a{
    margin :0  5px ;
}

.pagination_area ul{list-style:none;}
@media only screen and (max-width: 600px) {
  .paginationn-home .page-numbers {
    padding : 1px 10px;
  }
  .list-margin{
      margin-left: -60px;
  }
}
</style>


<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<div class="container">
                <div class="row">
                    <?php
                    if ( have_posts() ) :
                        while ( have_posts() ) :
                            the_post(); ?>
                            <div class="col-md-12 col-sm-12 col-lg-8 blog-padding">
                                <div class="right-blog blog-view">
                                    <div class="blog-cont">
                                        <div class="hisar-blog-tittle">
                                        	<h1><?php the_title(); ?></h1>
                                        </div>
                                        <?php the_content(); ?>
                                    </div>
                                </div>
                            </div>
                            <?php 
                            if ( comments_open() || get_comments_number() ) :
								comments_template();
							endif;
                        endwhile;
                    endif;
                    get_sidebar(); ?>     
            	</div>
            </div> 
		</main>
	</div>

<?php

get_footer();

	