<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package HisarFever
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
   	
   	<div id="primary" class="content-area">
		<main id="main" class="site-main">
			<div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-lg-8 blog-padding">
                        <div class="right-blog blog-view">
                            <div class="blog-cont">
                                <div class="hisar-blog-tittle">
                                	<a class="btn-link text-dark" href="<?php echo esc_url( get_the_permalink($post) ) ?>"><h2><?php echo get_the_title(); ?></h2></a>
                                </div>
                                <div class="thumbnail">
                                  <?php  hisar_fever_post_thumbnail('spost-thumbnail-size'); ?>
                            	</div>
                                <?php the_excerpt(); ?>
                                <a class="btn-link" href="<?php echo esc_url( get_the_permalink($post) ) ?>">Read More...</a>
                            </div>
                            <?php if ( 'post' === get_post_type() ) : ?>
                            <div class="author-info">
                                <hr><p>Posted By <?php echo ucfirst(hisar_fever_posted_by()); ?> on <?php hisar_fever_posted_on(); ?></p><hr>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php get_sidebar(); ?>     
            	</div>
            </div> 
		</main>
	</div>
</article><!-- #post-<?php the_ID(); ?> -->
