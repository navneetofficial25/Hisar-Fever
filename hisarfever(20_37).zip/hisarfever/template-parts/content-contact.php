<?php
/**
 * Template part for displaying Contact Us content
 * Template part for Service page 
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package education
 */

require_once get_template_directory() . '/inc/email_forms.php';
?>

     
      <div class="contact-us">
        <div class="hdr">
            <div class="container">
                 <div class="banner-text text-center size-banner">
                    <div class="contect fliter-heading">
                        <h1>Enough about us, <b>lets talk about you now !</b></h1>
                        <p>We would love to work with you and are waiting for you to drop us a line! Please fill out the form below to get in touch with us or request for a quote here. We’ll be sure to get back to you as soon as we can.</p>
                    </div>
                  </div>
             </div>
        </div> 
        
     </div> 
     <div class="contect-form">
         <div class="container" id="contect-info">
             <div class="row contact-form">
                 <div class="col-lg-7 col-xs-12">
                     <div class="group-form">
                        
                        <?php $form =  get_post_meta($post->ID, 'hisar_fever_custom_cf7', true); 
                               if(!empty($form)) {
                                echo do_shortcode($form);
                               } else{ 
                                echo 'Form Not Available';
                               }
                        ?>
                     </div>
                 </div>
                 <div class="col-lg-5 col-xs-12" style="padding: 0">
                     <div class="contact-info">
                         <div class="uper-info">
                             <p>If you prefer a more tangible form of communication we're here:</p>
                             <div class="line"></div>
                         </div>
                         <div class="buttom-info">
                             <div class="address">
                                 <div class="info-img">
                                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                                     <!--<img src="<?php bloginfo('template_url'); ?>/assets/img/location.png">-->
                                 </div>
                                 <div class="con-info">
                                     <p>Reach us on our</p>
                                     <h3>Office</h3>
                                     <p class="address-text">Ground Floor,  Rajmahal Complex, Opp. PLA Petrol Pump, Delhi Road, Hisar Haryana 125001</p>
                                 </div>
                             </div>
                             <div class="address">
                                 <div class="info-img">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                     <!--<img src="<?php bloginfo('template_url'); ?>/assets/img/phone.png">-->
                                 </div>
                                 <div class="con-info">
                                     <p>Give us a</p>
                                     <h3>Call</h3>
                                     <p class="address-text">+91 925 400 0000 </p>
                                     <p class="address-text">+91 819 893 2943</p>
                                 </div>
                             </div>
                             <div class="address">
                                 <div class="info-img">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                     <!--<img src="<?php bloginfo('template_url'); ?>/assets/img/message.png">-->
                                 </div>
                                 <div class="con-info">
                                     <p>Drop an</p>
                                     <h3>Email</h3>
                                     <p class="address-text">hisarfever@gmail.com</p>
                                     <p class="address-text">vikaspoonia17@gmail.com</p>
                                 </div>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>