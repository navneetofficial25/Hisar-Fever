<?php
/**
 * 
 * 
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package education
 */
?>
<div class="banner"></div>
<section class="portfolio">
      <div class="container">
        <h2 class="text-center"><span>We couldn't fit them all.</span> Here are selected few...</h2>
        <div class="portfolio-wrap">
          <div class="row">
            <div class="col-xs-12 ">
                <div class="nav nav-tabs nav-fill " id="nav-tab" role="tablist">

                  
                  <?php 
                     $counter = 0;
                    $get_terms= get_terms( array('taxonomy' => 'ocean_portfolio_category', 'hide_empty' => false,) );
                    foreach ( $get_terms as $get_term ):  ?>
                        <a class="nav-item nav-link my-2 <?php if ($counter == 0){ echo " active"; }?>"  data-toggle="tab" href="#nav<?php echo $get_term->term_id; ?>" role="tab"  aria-selected="false"><?php echo $get_term->name; ?></a>
                    
                    <?php 
                     $counter++;
                    endforeach; ?>
                    
                  </div>
                  <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                  <?php
                    $counter = 0;
                    $get_terms= get_terms( array('taxonomy' => 'ocean_portfolio_category', 'hide_empty' => false,) );
                    foreach ( $get_terms as $get_term ): ?>
                    <div class="tab-pane fade <?php if ($counter == 0){ echo " active show"; }?>" id="nav<?php echo $get_term->term_id; ?>" role="tabpanel" aria-labelledby="nav<?php echo $get_term->term_id; ?>-tab">
                      <div class="row">
                    <?php $magazine_args = array(
                             'post_type' => 'ocean_portfolio',
                              'posts_per_page' => -1,
                              'order' => 'DESC',
                              'tax_query' => array( array(
                                                        'taxonomy' => 'ocean_portfolio_category',
                                                        'field' => 'term_id',
                                                        'terms' => $get_term->term_id,
                                                         ),
                                                  ),
                             );
                    $info_newses = new WP_Query($magazine_args);
                      if( $info_newses->have_posts() ) :
                         while ($info_newses->have_posts()) : $info_newses->the_post(); ?>
                                  
                                    
                                        <?php 
                                       $video_url =  get_post_meta(get_the_ID(), 'video_url', TRUE); 
                                       if(!empty($video_url)) { ?>
                                        <div class="col-md-3">  
                                          <a class="lightbox" href="#model<?php echo get_the_ID(); ?>">
                                             <?php the_post_thumbnail('full', array( 'class' => 'w-100 h-auto')); ?>
                                          </a> 
                                          <div class="lightbox-target" id="model<?php echo get_the_ID(); ?>">
                                            <iframe class="video_model" width="560" height="315" src="<?php echo $video_url; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
                                              
                                            </iframe>
                                            <a class="lightbox-close" href="#"></a>
                                          </div>
                                        </div>
                                        <?php 
                                       } else{ ?>
                                       
                                        <div class="col-md-3">  
                                          <a class="lightbox" href="#model<?php echo get_the_ID(); ?>">
                                              <?php the_post_thumbnail('full', array( 'class' => 'w-100 h-auto')); ?>
                                          </a> 
                                          <div class="lightbox-target" id="model<?php echo get_the_ID(); ?>">
                                            <?php the_post_thumbnail('full'); ?>
                                            <a class="lightbox-close" href="#"></a>
                                          </div>
                                        </div>

                                        <?php //the_post_thumbnail('thumbnail');
                                       }

                                       ?>
                                  
                                  <?php     
                         endwhile;
                            wp_reset_postdata();
                     else :
                            esc_html_e( 'No testimonials in the diving taxonomy!', 'text-domain' );
                     endif; ?> 
                    </div>
                     </div>
                    <?php 
                         $counter++;
                        endforeach;
                    ?>
                   
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Footer Start -->
<style>
    .btn-zweezle {
    padding: 15px 30px;
    margin: 0;
    background: linear-gradient(to right, #feb900 0%, #ffd200 100%);
    border: 2px solid #ffd101;
    text-transform: uppercase;
    color: #000;
    transition: all 0.5s;
    border-radius: 10px;
    
}
.btn-zweezle:hover {
    color : black;
    background: white;
}
.btnn{
display: inline-block;
    padding: 6px 12px;
    margin-bottom: 0;
    font-size: 14px;
    font-weight: 700;
    line-height: 1.42857143;
    text-align: center;
    white-space: nowrap;
    vertical-align: middle;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;

}

.col-md a{
    text-decoration: none;
}
.ok{
     font-size: 2.5rem; 
}

@media (max-width: 480px){
.btn-zweezle {
    padding: 8px 7px;
    margin: 10px auto;
    font-size: 10px;
}
.ok{
     font-size: 1.5rem; 
}
}
</style>
<section>
    <div class="container">
        <h2 class="text-center ok" style="text-transform:none;"><spna style="font-weight: 400;"><b>Need more?</b></spna> <span style="color : #666666">Check out our</span> 
        <div class="col-md"> 
        <a href="" target="_blank" class="btnn btn-zweezle">Videos @ Youtube</a> 
        <a href="" target="_blank" class="btnn btn-zweezle">Photography @ Insta</a>  
        <a href="" target="_blank" class="btnn btn-zweezle">Designs @ pinterest</a></div></h2>
        
    </div>
    
</section>