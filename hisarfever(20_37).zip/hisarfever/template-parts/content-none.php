<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package HisarFever
 */

?>
<style>

.search-content-none{
	margin-top:80px;
	
}
.search-content-none p {color:#000; font-size: 18px;}
.search-content-none .search-form {text-align:center; margin-top:50px;}

.search-content-none .screen-reader-text {display:none;margin-top:50px;}
</style>
<section class="no-results not-found">
	<header class="page-header">
		<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'hisar-fever' ); ?></h1>
	</header><!-- .page-header -->

	<div class="container">
        <div class="row">
        	<div class="col-md-12 col-sm-12 col-lg-8 blog-padding">

				<div class="page-content search-content-none">
					<?php
					if ( is_home() && current_user_can( 'publish_posts' ) ) :

						printf(
							'<p>' . wp_kses(
								/* translators: 1: link to WP admin new post page. */
								__( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'hisar-fever' ),
								array(
									'a' => array(
										'href' => array(),
									),
								)
							) . '</p>',
							esc_url( admin_url( 'post-new.php' ) )
						);

					elseif ( is_search() ) :
						?>

						<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'hisar-fever' ); ?></p>
						<?php
						get_search_form();

					else :
						?>

						<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'hisar-fever' ); ?></p>
						<?php
						get_search_form();

					endif;
					?>
				</div><!-- .page-content -->
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>
</section><!-- .no-results -->
<?php get_sidebar();

