<?php
/**
 *
 * The main Single Blog template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package education
 */


?> 
<!--================Start Blog Main Area =================-->


<!--================End Blog Main Area =================-->
<style>
    
    .blog-view p,li{
        font-size : 15px;
    }
    .blog-view span{
        line-height: 37px;
    }
    .blog-view a{
        color : black;
    }
    .blog-view a:hover{
        color : #ffd101;
    }
    .blog-view img{
        width :100%;
        height : auto;
    }
    .blog-view .card-header img{
        height : 100px;
    }
    .comment-author img{border-radius: 50%; width:65px;height:60px;}
    .user_name{
        font-size:14px;
        font-weight: bold;
    }
    .comments-list .media{
        border-bottom: 1px dotted #ccc;
    }
    .popular-img{
        max-width : none;
        height : auto;
        width : 90px;
    }
</style>
   <section class="hisar-single-blog-warper">
        <div class="single-blog">
            <div class="container">
                <div class="row">
                <div class="col-md-12">
                    <div class="right-blog">
                        <div class="blog-cont">
                            <div class="blog-view">
                            <div class="hisar-blog-tittle">
                                <h1><?php echo the_title();?></h1>
                            </div>
                           <?php $author_id=$post->post_author; ?>
                           <p>Posted By <?php echo ucfirst(get_the_author_meta('display_name', $author_id)); ?> on <?php the_date('F, jS '); ?></p><hr>
                           
                            <div class="blog-description">
                                <?php the_content();?> 
                            </div>
                            </div>
                           
                           
                        </div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </section>
    <?php //wp_list_comments(); ?>
    <!-- Blog End -->


<script>
    function(event) {
  if (hostname = $(this).prop("hostname"), pathname = $(this).prop("pathname"), qs = $(this).prop("search"), hash = $(this).prop("hash"), pathname.length > 0 && "/" != pathname.charAt(0) && (pathname = "/" + pathname), window.location.hostname == hostname && window.location.pathname == pathname && window.location.search == qs && "" !== hash) {
    var hash_selector = hash.replace(/([ !"$%&'()*+,.\/:;<=>?@[\]^`{|}~])/g, "\\$1");
    if ($(hash_selector).length > 0 ? target = hash : (anchor = hash, anchor = anchor.replace("#", ""), target = 'a[name="' + anchor + '"]', 0 == $(target).length && (target = "")), void 0 !== ezTOC.scroll_offset) var offset = -1 * ezTOC.scroll_offset;
    else {
      var adminbar = $("#wpadminbar");
      offset = adminbar.length > 0 && adminbar.is(":visible") ? -30 : 0
    }
    target && $.smoothScroll({
      scrollTarget: target,
      offset: offset,
      beforeScroll: deactivateSetActiveEzTocListElement,
      afterScroll: function() {
        setActiveEzTocListElement(), activateSetActiveEzTocListElement()
      }
    })
  }
}
</script>
<script>
    function(a) {
  return void 0 === n || a && n.event.triggered === a.type ? void 0 : n.event.dispatch.apply(k.elem, arguments)
}
</script>
    
    

        