<?php
/**
 *
 * The main Single Blog template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package education
 */


?> 
<!--================Start Blog Main Area =================-->


<!--================End Blog Main Area =================-->
<style>
    
    .blog-view p,li{
        font-size : 15px;
    }
    .blog-view span{
        line-height: 37px;
    }
    .blog-view a{
        color : black;
    }
    .blog-view a:hover{
        color : #ffd101;
    }
    .blog-view img{
        width :100%;
        height : auto;
    }
    .blog-view .card-header img{
        height : 100px;
    }
    .comment-author img{border-radius: 50%; width:65px;height:60px;}
    .user_name{
        font-size:14px;
        font-weight: bold;
    }
    .comments-list .media{
        border-bottom: 1px dotted #ccc;
    }
    .popular-img{
        max-width : none;
        height : auto;
        width : 90px;
    }
</style>
   <section class="hisar-single-blog-warper">
        <div class="single-blog">
            <div class="container">
                <div class="row">
                <div class="col-md-12 col-sm-12 col-lg-8 blog-padding">
                    <div class="right-blog">
                        <div class="blog-cont">
                            <div class="blog-view">
                            <div class="hisar-blog-tittle">
                                <h1><?php echo the_title();?></h1>
                            </div>
                            <div class="thumbnail">
                                  <?php  the_post_thumbnail('spost-thumbnail-size'); ?>
                            </div>
                            <div class="author-info">
                                <?php  $author_id=$post->post_author; ?>
                                <hr><p>Posted By <?php echo ucfirst(get_the_author_meta('display_name', $author_id)); ?> on <?php the_date('F, jS '); ?></p><hr>
                            </div>
                            <div class="blog-description">
                                <?php the_content();?> 
                            </div>
                            </div>
                            <div class="related-blog">
                                <div class="related-blog-tittle">
                                    <hr><h4 class="text-uppercase"> You Might Also Like </h4>
                                </div>
                                <div class="row">
                                	<?php
                                	$args = array(
											    'post_type' => 'post',
											    'orderby'   => 'rand',
											    'posts_per_page' => 3, 
											    );
											 
											$the_query = new WP_Query( $args );
											 
											if ( $the_query->have_posts() ) { 
												while ( $the_query->have_posts() ) {
										        $the_query->the_post(); ?>
                                    <div class="col-lg-4 col-md-4 col-xs-12">
                                        <div class="card">
                                            <div class="card-header">
                                                <?php  the_post_thumbnail('spost-thumbnail-size'); ?>
                                            </div>
                                            <div style="min-height: 150px;" class="card-body">
                                                <h6><a href="<?php echo get_permalink(); ?>"><?php echo the_title();?></a></h6>
                                                
                                                <time class="published" datetime="2018-10-12T14:40:37+00:00"><i class="fa fa-clock-o" aria-hidden="true"></i><?php the_date('F, jS '); ?></time>
                                            </div>
                                        </div>
                                    </div>
                                <?php } wp_reset_postdata(); } ?>
                                    
                                </div>
                            </div>
                            <?php comments_template(); ?>
                            <div class="hisar-reply">
                                <div class="comment-form-grup">
                                    <?php //comment_form( 'placeholder_author_email_url_form_fields' ); ?>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <?php get_sidebar();
                ?>
                

                
            </div>
            </div>
        </div>
    </section>
    <?php //wp_list_comments(); ?>
    <!-- Blog End -->


<script>
    function(event) {
  if (hostname = $(this).prop("hostname"), pathname = $(this).prop("pathname"), qs = $(this).prop("search"), hash = $(this).prop("hash"), pathname.length > 0 && "/" != pathname.charAt(0) && (pathname = "/" + pathname), window.location.hostname == hostname && window.location.pathname == pathname && window.location.search == qs && "" !== hash) {
    var hash_selector = hash.replace(/([ !"$%&'()*+,.\/:;<=>?@[\]^`{|}~])/g, "\\$1");
    if ($(hash_selector).length > 0 ? target = hash : (anchor = hash, anchor = anchor.replace("#", ""), target = 'a[name="' + anchor + '"]', 0 == $(target).length && (target = "")), void 0 !== ezTOC.scroll_offset) var offset = -1 * ezTOC.scroll_offset;
    else {
      var adminbar = $("#wpadminbar");
      offset = adminbar.length > 0 && adminbar.is(":visible") ? -30 : 0
    }
    target && $.smoothScroll({
      scrollTarget: target,
      offset: offset,
      beforeScroll: deactivateSetActiveEzTocListElement,
      afterScroll: function() {
        setActiveEzTocListElement(), activateSetActiveEzTocListElement()
      }
    })
  }
}
</script>
<script>
    function(a) {
  return void 0 === n || a && n.event.triggered === a.type ? void 0 : n.event.dispatch.apply(k.elem, arguments)
}
</script>
    
    

        