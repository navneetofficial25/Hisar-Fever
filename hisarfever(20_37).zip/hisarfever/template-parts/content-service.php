<?php
/**
 * Template part for displaying Service content
 * Template part for Service page 
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package education
 */

require_once get_template_directory() . '/inc/email_forms.php';
require_once get_template_directory() . '/template-parts/model.php';
?>
<!-- Business Rank Start -->
   
    <section>
        <div class="hisar-services-banner-warper">
            <div class="services-banner">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-12">
                            <div class="left-cont">
                                <div class="cont-info">
                                    <div id="search">
                                        <label for="search-input"><img src="<?php bloginfo('template_url'); ?>/assets/images/search.png"><span class="sr-only">Search icons</span></label>
                                        <input id="search-input" class="form-control input-lg"  placeholder="Digital Marketing Agency in Hisar" autocomplete="off" spellcheck="false" autocorrect="off" tabindex="1">
                                    </div>
                                    <div class="services-banner-text">
                                        <h1>Hisar fever</h1>
                                        <p>We talks numbers and so do our clients, we are professionals that believe in making impact. We specialize in Hotels, Bars & Restaurants, E-commerce, NGOs, Health Sector & Education. Over 50+ Clients. We Generate 3X Revenue. Generate High ROI. 24X7 Support.</p>
                                        <a class="btn cont-btn" href="">Contact us now !</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-1 col-12"></div>
                        <div class="col-md-5 col-12">
                            <div class="form">
                                <div class="">
                                    <div class="rght-cont">
                                <div class="cont-form">
                                    <div class="form-tittle">
                                        <p>Request a free</p>
                                        <h2>business audit ?</h2>
                                    </div>
                                    <?php 
                                        $all_errors = $audit_error;

                                        if (!empty($all_errors)){
                                            foreach($all_errors as $key=>$err){ ?>
                                                <div class="error-info"> <span class="error"> <?php echo $err[0] ?></span> </div>
                                                <?php
                                            }
                                        }
                                        if(empty($all_errors)) {
                                            if(isset( $_POST['send_audit_mail']) ) {

                                                ?>
                                                <div class="success-info"> <span class="success">Form submitted successfully, Thank you.</span> </div>
                                                <?php
                                            }
                                            unset($_POST);
                                        }
                                        else{
                                            $data = $_POST;
                                        }

                                    ?>
                                    <form method="post" action="<?php echo get_permalink(); ?>" >
                                        <div class="form-info">
                                         <?php $form =  get_post_meta($post->ID, 'hisar_fever_custom_cf7', true); 
                                               if(!empty($form)) {
                                                echo do_shortcode($form);
                                               } else{ 
                                                echo 'Form Not Available';
                                               }
                                        ?>
                                           
                                        </div>
                                        <div class="form-buttom-text text-center">
                                            <p>Get call from our experts within</p>
                                            <h2>24 Hours</h2>
                                            <input type="submit" name="send_audit_mail" class="wpcf7-form-control wpcf7-submit btn send-btn" value="Send Now">
                                        </div>
                                    </form>
                                    
                                </div>
                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services-Banner End -->

    <section>
        <div class="hisar-business-rank-warper">
            <div class="business-rank">
                <div class="rank-info">
                    <div class="container">
                        <div class="rank-tittle text-center">
                            <h2>Brand your content <b>Rank your Business!</b></h2>
                        </div>
                        <div class="rank-tittle-info text-left">
                            <p>Any enterprise today, will understand the value and returns behind the first page internet search result of their web page with a relevant search keyword. Any enterprise today, will understand the value and returns behind the first page internet search result of their web page with a relevant search keyword.</p>
                        </div>
                        <div class="rank-points">
                            <div class="row">
                                <div class="col-md-6 col-12">
                                    <div class="lft-info">
                                        <div class="point">
                                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-3.png">
                                            <p>Any enterprise today, will understand the value and returns behind the first page internet search result of their web page with a relevant search keyword.</p>
                                        </div>
                                        <div class="point">
                                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-3.png">
                                            <p>Any enterprise today, will understand the value and returns behind the </p>
                                        </div>
                                        <div class="point">
                                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-3.png">
                                            <p>Any enterprise today, will understand the value and returns behind the first page internet search result</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-12">
                                    <div class="rgt-info">
                                        <div class="point">
                                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-3.png">
                                            <p>Any enterprise today, will understand the value and returns behind the first page internet search result</p>
                                        </div>
                                        <div class="point">
                                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-3.png">
                                            <p>Any enterprise today, will understand the value and returns behind the first page internet search result</p>
                                        </div>
                                        <div class="point">
                                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-3.png">
                                            <p>Any enterprise today, will understand the value and returns behind the first page internet search result of their web page with a relevant search keyword.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Business Rank Emd -->

    <!-- Services Start -->

    <section>
        <div class="hisar-services-warper">
            <div class="services">
                <div class="container">
                    <div class="services-tittle text-center">
                        <h2><b>Services</b> That Drive Results</h2>
                    </div>
                    <div class="row">

                    	<?php $loop = new WP_Query( array( 'post_type' => 'ocean_services', 'posts_per_page' => -1 ) ); ?>
						<?php while ( $loop->have_posts() ) : $loop->the_post(); ?>

	                        <div class="col-md-4 col-sm-4 col-sm-12 text-center">
	                            <div class="card services-card">
	                                <div class="card-body" style="padding: 40px 20px;">
	                                    <?php the_post_thumbnail('thumbnail',array( 'class' => 'service-icon')); ?>
	                                    <h3><?php echo get_the_title(); ?></h3>
	                                    <?php the_excerpt();?>
	                                    <a class="btn read-btn" href="<?php the_permalink(); ?>">Read More</a>
	                                </div>
	                            </div>
	                        </div>
                        <?php endwhile; wp_reset_query(); ?>

                    </div>
                    <div class="portfolio-btn text-center">
                        <a class="btn check-btn" href="">Check Our Portfolio</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services End -->

    <!-- Marketing Start -->

    <section>
        <div class="hisar-marketing-warper">
            <div class="marketing">
                <div class="container">
                    <div class="merketing-tittle">
                        <h1><b>Why Hisar Fever</b> For Your Digital Marketing Needs ?</h1>
                    </div>
                    <div class="merketing-describe">
                        <p>Digital Marketing Agency works with businesses large and small. We connect each project with the right professionals who have ample experience working on companies at each scale and specialization. This ensures that the right people are working on each project. Whether you’re a small business looking to reach your local audience or a large, multinational brand looking to launch a new product in numerous markets.</p>
                    </div>
                    <div class="merketing-points">
                        <div class="point">
                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-12.png">
                             <p>Any enterprise today, will understand the value and returns behind the first page internet search result of their web page with a relevant search keyword.</p>
                        </div>
                        <div class="point">
                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-12.png">
                             <p>Any enterprise today, will understand the value and returns behind the</p>
                        </div>
                        <div class="point">
                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-12.png">
                             <p>Any enterprise today, will understand the value and returns behind the first page internet search result</p>
                        </div>
                        <div class="point">
                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-12.png">
                             <p>Any enterprise today, will understand the value and returns behind the first page internet search result of their web page with a relevant search keyword.</p>
                        </div>
                        <div class="point">
                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-12.png">
                             <p>Any enterprise today, will understand the value and returns behind the</p>
                        </div>
                        <div class="point">
                            <img src="<?php bloginfo('template_url'); ?>/assets/images/icon-12.png">
                             <p>Any enterprise today, will understand the value and returns behind the first page internet search result of their web page with a relevant search keyword.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Marketing End -->

    <!-- Questions Start -->
<style>
        .accordion .card-header:after {
        font-family: 'FontAwesome';  
        content: "\f068";
        float: right; 
    }
    .accordion .card-header.collapsed:after {
        /* symbol for "collapsed" panels */
        content: "\f067"; 
    }
</style>

<?php echo do_shortcode( '[hisar-faq]'); ?>

    <section>
        <div class="footer">
            <div class="hdr">
            <div class="container">
                 <div class="footer-text text-center">
                    <div class="footer-contect">
                        <h1>Ready To <b>Grow Your Business</b></h1>
                        <p>Contact us to work with a result driven digital marketing agency</p>
                        <div class="row">
                            <div class="col-md-5">
                                <a class="btn footer-btn" data-toggle="modal" data-target="#modalLoginForm"><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-2.png">Get Free Proposal</a>
                            </div>
                            <div class="col-md-2">
                                <div class="footer-or">
                                    <p>or</p>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <a class="btn footer-btn" href=""><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-1.png">Call 925 400 0000</a>
                            </div>
                            
                        </div>
                    </div>
                  </div>
             </div>
        </div>
        </div>
    </section>
     
    <!-- Questions End -->