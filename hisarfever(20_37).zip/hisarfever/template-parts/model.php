<?php

/*function load_default_js() {
	wp_enqueue_script('jquery');
}

add_action('init', 'load_default_js');*/
require_once get_template_directory() . '/inc/email_forms.php';
?>

<script>

	/*jQuery("#submit_model_form_id").on("click", function($){

    console.log("[form verify ]");

	$("#NAME_ERROR_ID").hide();
	var name = $("#NAME_ID").val();
	console.log("firstName is ", name);
	if (isEmptyString (name)) {
		$("#NAME_ERROR_ID").show();
		$("#NAME_ID").focus();
		return false;
	}

	return true;

	
});*/

</script>

<div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
     	<div class="modal-header text-center">
        	<h4 class="modal-title w-100 font-weight-bold">Get Proposal</h4>
        	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          		<span aria-hidden="true">&times;</span>
        	</button>
     	</div>
	      <div class="modal-body mx-3">
			<?php $form =  get_post_meta($post->ID, 'hisar_fever_custom_cf7', true); 
			//$form = '';
				   if(!empty($form)) {
				   	echo do_shortcode($form);
				   } else{ 
				   	echo do_shortcode('[contact-form-7 id="3112" title="Contact-page"]');
				   }
			?>
	        <!-- <form method="POST" action="<?php echo get_permalink(); ?>">
	            <div class="form-group">
	    			<label for="email">Name:</label>
	    				<input type="text" name="fullname" class="form-control" id="NAME_ID" required>
	    				<span style="display:none" class="error" id="NAME_ERROR_ID" >Please Enter Name</span>
	  			</div>
	   			<div class="form-group">
	    			<label for="email">Email address:</label>
	    			<input type="email" name="email" class="form-control" id="email" required>
	  			</div>
	  			<div class="form-group">
	    			<label for="contact">Contact No:</label>
	    			<input type="text" name="contact" class="form-control" id="contact" required>
	  			</div>
	  			<div class="form-group">
	    			<label for="city">City :</label>
	    			<input type="text" name="city" class="form-control" id="pwd" required>
	  			</div>
	      </div>
	        <div class="modal-footer d-flex justify-content-center">
	        	<input type="submit" name="submit_model_form" id="submit_model_form_id" value="Get Now" class="btn btn-default size"/>
	        	
	    	</div>
    	</form> -->
    </div>
  	  </div>
	</div>
</div>