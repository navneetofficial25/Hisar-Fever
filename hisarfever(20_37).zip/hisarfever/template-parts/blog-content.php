<?php
/**
 *
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package education
 */


?> 
    <div class=" col-md-4 col-xm-12">
        <div class="card">
            <div class="card-cont">
                <div class="card-header">
                    <a href="<?php the_permalink(); ?>"  >
                       <?php 
                        if( has_post_thumbnail() ) {
                            the_post_thumbnail('post-thumbnail-size');
                        } else{
                            ?><img src="<?php echo bloginfo('template_url');?>/assets/images/dummy.jpg"><?php 
                        }
                        

                       ?>
                    </a>
                </div>
                <div class="card-body">
                    <a class="btn-link text-dark" href="<?php echo esc_url( get_the_permalink($post) ) ?>"><h4><?php echo get_the_title(); ?></h4></a>
                    <p><?php the_excerpt();?></p>
                    <a class="btn-link" href="<?php echo esc_url( get_the_permalink($post) ) ?>">Read More...</a>
                </div>
                <div class="card-footer">
                    <div class="card-user">
                        <?php //echo wphf_get_post_views(get_the_ID()); 
                            $author_id=$post->post_author;
                        ?>
                        <p>BY <?php echo ucfirst(get_the_author_meta('display_name', $author_id)); ?>  |  <?php the_date('F, jS '); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <!--================End Blog Main Area =================-->
        
       