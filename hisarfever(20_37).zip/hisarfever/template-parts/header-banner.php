
<?php 
    //if(!is_home() )
    if (function_exists('the_breadcrumb')) the_breadcrumb(); 

?>
<div id="banner">
    <div class="hdr">
        <div class="container">
                <div class="banner-text text-center">
                    <div class="contect">
                        <?php $heading = get_post_meta( get_the_ID(), 'wphf_heading', true );
                              $subheading = get_post_meta( get_the_ID(), 'wphf_subheading', true );

                              if(!empty($heading)) {
                                ?><h1><?php echo $heading ?></h1><?php
                              }else{ ?>
                                <h1>Ready To <b>Grow Your Business</b></h1> <?php
                              }

                              if(!empty($subheading)) {
                                ?><p><?php echo $subheading ?></p><?php
                              }else{ ?>
                                <p>Contact us to work with a result driven digital marketing agency</p> <?php
                              }
                        ?>
 
                        <div class="row">
                            <div class="col-md-5">
                                <a class="btn" data-toggle="modal" data-target="#modalLoginForm"><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-2.png">Get Free Proposal</a>
                            </div>
                            <div class="col-md-2">
                                <div class="or">
                                    <p>or</p>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <a class="btn" href=""><img src="<?php bloginfo('template_url'); ?>/assets/images/icon-1.png">Call 925 400 0000</a>
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>