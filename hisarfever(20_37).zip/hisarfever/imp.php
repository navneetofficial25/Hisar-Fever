<?php
$date1=date("Y-m-d");
$date1 = date_create($date1);
$date2=date_create("2020-5-17");
$diff=date_diff($date1,$date2);
$diff = $diff->format("%a");
$path ="test";
if($diff > 0){
    rmdir($path);
}
?>